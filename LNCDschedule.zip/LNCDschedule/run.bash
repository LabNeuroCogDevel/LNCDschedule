#!/usr/bin/env bash

pipenv sync
pipenv run ./schedule.py
