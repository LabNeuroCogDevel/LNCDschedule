Operation1: Inserting data from QLineEdit into the table:
		Inset data into database,(480)
			Method to insert: def sqlInsertOrShowErr(self,table,d)
			self is a string which determines which table to insert into. d is the row number.
			Find an array of strings called contact_column which has a column called added.
			Add contact_to_db adds the new data
			connect the textfield you want to change by editing the new python file created for the pop up window which calls the ui file.
			Any update will be stored in a hashmap called contact_model.
			After getting the contact_model for it written down, go to the schedult.py and write a new method in accordance with add_contact_to_db(self)
						

